<?php
namespace Custom\ProductColor\Plugin;

use Psr\Log\LoggerInterface;
use Magento\Catalog\Model\Product;

class ProductSave
{
    private $logger;

    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    public function beforeSave(Product $product)
    {
        $bgColor = $product->getData('bg_color');

        if ($bgColor !== null) {
            $this->logger->debug('Setting bg_color attribute value: ' . $bgColor);
            $product->setData('bg_color', $bgColor);
            //$product->save(); // Save the product to persist the attribute value
        }

        return [$product]; // Return modified product data
    }
}
