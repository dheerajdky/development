var config = {
    map: {
        '*': {
            'customColorPicker': 'Custom_ProductColor/js/form/element/pickcolors'
        }
    }
};
