define([
    'Magento_Ui/js/form/element/color-picker'
], function (ColorPicker) {
    'use strict';

    return ColorPicker.extend({
        /**
         * Convert RGB color to hexadecimal color format.
         *
         * @param {String} rgbColor - RGB color string (e.g., "255,255,255")
         * @returns {String} Hexadecimal color string (e.g., "#ffffff")
         */
        rgbToHex: function (rgbColor) {
            if (!rgbColor) {
                return '';
            }
            var rgbValues = rgbColor.split(',').map(function (value) {
                return parseInt(value);
            });
            var hexColor = '#' + rgbValues.map(function (value) {
                return ('0' + value.toString(16)).slice(-2);
            }).join('');
            return hexColor.toUpperCase();
        },

        /**
         * Convert hexadecimal color to RGB color format.
         *
         * @param {String} hexColor - Hexadecimal color string (e.g., "#ffffff")
         * @returns {String} RGB color string (e.g., "255,255,255")
         */
        hexToRgb: function (hexColor) {
            if (!hexColor) {
                return '';
            }
            hexColor = hexColor.replace('#', '');
            var r = parseInt(hexColor.substring(0, 2), 16);
            var g = parseInt(hexColor.substring(2, 4), 16);
            var b = parseInt(hexColor.substring(4, 6), 16);
            return r + ',' + g + ',' + b;
        },

        /**
         * Override parent method to convert color format.
         *
         * @param {String} value - Current color value (RGB or hex)
         */
        setValue: function (value) {
            if (value && value.indexOf('#') === 0) {
                value = this.hexToRgb(value);
            }
            this._super(value);
        },

        /**
         * Override parent method to convert color format.
         *
         * @returns {String} Current color value (RGB or hex)
         */
        getValue: function () {
            var value = this._super();
            if (value && value.indexOf(',') !== -1) {
                value = this.rgbToHex(value);
            }
            return value;
        }
    });
});
