<?php
namespace Custom\ProductColor\Ui\Modifier\Product;

use Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractModifier;

class Style extends AbstractModifier
{
    public function modifyMeta(array $meta)
	{
		// Color attribute code
		$code = 'bg_color';

		// Check if the array key exists before modifying it
		if (isset($meta['product-details']['children']['container_' . $code]['children'])) {
			$meta['product-details']['children']['container_' . $code]['children'] = array_replace_recursive(
				$meta['product-details']['children']['container_' . $code]['children'],
				[
					$code => [
						'arguments' => [
							'data' => [
								'config' => [
									'component' => 'Custom_ProductColor/js/form/element/pickcolors'
								]
							]
						]
					]
				]
			);
		} else {
			// Handle case where the specified container key does not exist
			// You can log a message or take appropriate action here
			// Example: log error message
			$logger = \Magento\Framework\App\ObjectManager::getInstance()->get(\Psr\Log\LoggerInterface::class);
			$logger->error('Container key "container_' . $code . '" not found in $meta array.');
		}

		return $meta;
	}


   public function modifyData(array $data)
   {
       return $data;
   }
}